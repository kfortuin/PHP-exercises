<!doctype html>
<html>
<head>
	<title>Raadsel</title>
	<link href="style.css" rel="stylesheet" type="text/css" >
</head>
<body class="smokey">
	<div class="frame">
		<div class="header">
			<h1>Raadsel</h1>
		</div>
		<div class="menu">
			<ul>
				<li><a href="index.php">Home</a></li>
				<li><a href="riddle.php">Raadsel</a></li>
				<li><a href="campfire.php">Sfeertje</a></li>
				<li><a href="club.php">Kampvuurclub</a></li>
			</ul>
		</div>		
		<div class="content">
			<div class="riddle">
				<h2>Samen dood</h2>
				<p>Marie en Vincent liggen op de grond in een plas water, dood. Er liggen glasscherven. Het raam staat open.</p>
			</div>
			<div class="hints">
				<h2>Hints</h2>
				<ul>
					<li>Waren Marie en Vincent wel mensen?</li>
					<li>Is er iets gevallen?</li>
					<li>Zijn Marie en Vincent verdronken?</li>
					<li>Zijn Marie en Vincent vermoord?</li>				
				</ul>
			</div>
			<div class="solution">
				<h2>Het verhaal</h2>
				<div class="story">
					<p>Marie en Vincent waren twee goudvissen in een glazen vissekom. Die stond op een vensterbank voor een niet goed afgesloten raam.</p>
					<p>Het stormt buiten, waardoor het raam naar binnen openslaat.</p>
					<p>De vissenkom wordt van de vensterbank gestoten en valt kapot op de vloer. Marie en Vincent sterven een verschrikkelijke verstikkingsdood op het droge.</p>
				</div>
			</div>
		</div>
		<div class="footer">
			<p>&copy; 2013 de kampvuurclub</p>
		</div>
	</div>
</body>
</html>